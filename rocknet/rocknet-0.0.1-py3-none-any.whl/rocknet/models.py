import torch
import torch.nn as nn

from torchvision.models import (
    resnet50,
    ResNet50_Weights,
    densenet169,
    DenseNet169_Weights,
)
from torch.utils.data import DataLoader

from mdataset.rocknet import RockNet
from iapytoo.train.factories import Model, ModelFactory


class RocknetResnet50(Model):
    def __init__(self, loader: DataLoader, config) -> None:
        super().__init__(loader, config)
        self.resnet50 = resnet50(weights=ResNet50_Weights.DEFAULT)

        dataset: RockNet = loader.dataset

        input_size = self.resnet50.fc.in_features
        # No need to add a SoftMax if a CrossEntropyLoss is used :-)
        self.resnet50.fc = nn.Linear(input_size, dataset.n_classes)

    def forward(self, x):
        y = self.resnet50(x)
        return y


class RocknetDensenet169(Model):
    def __init__(self, loader: DataLoader, config) -> None:
        super().__init__(loader, config)
        self.densenet169 = densenet169(weights=DenseNet169_Weights.DEFAULT)

        dataset: RockNet = loader.dataset

        input_size = self.densenet169.classifier.in_features
        # No need to add a SoftMax if a CrossEntropyLoss is used :-)
        self.densenet169.classifier = nn.Linear(input_size, dataset.n_classes)

    def forward(self, x):
        y = self.densenet169(x)
        return y
