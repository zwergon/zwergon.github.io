from torchvision import transforms

from iapytoo.predictions.predictors import MaxPredictor
from iapytoo.predictions.plotters import ConfusionPlotter, TSNEPlotter
from iapytoo.utils.config import Config
from iapytoo.train.training import Training

from iapytoo.train.factories import ModelFactory
from rocknet.models import RocknetResnet50, RocknetDensenet169


class RocknetTraining(Training):
    def __init__(self, config: Config) -> None:
        super().__init__(config, metric_names=["accuracy"], predictor=MaxPredictor())

        factory = ModelFactory()
        factory.register_model("resnet50", RocknetResnet50)
        factory.register_model("densenet169", RocknetDensenet169)

        self.predictions.add_plotter(ConfusionPlotter())
        self.predictions.add_plotter(TSNEPlotter())

        # the training transforms
        self.train_transform = transforms.Compose(
            [
                transforms.Resize((config.image_size, config.image_size)),
                transforms.ToTensor(),
                transforms.RandomHorizontalFlip(),
                transforms.RandomVerticalFlip(),
                transforms.RandomRotation(config.rotation),
            ]
        )

        self.test_transform = transforms.Compose(
            [
                transforms.Resize((config.image_size, config.image_size)),
                transforms.ToTensor(),
            ]
        )
