import psycopg2 as pg
from psycopg2.errorcodes import UNIQUE_VIOLATION
import PIL.Image as Image
import io
import hashlib
import uuid
from PIL import Image
import numpy as np
import io
from psycopg2 import errors
import pandas as pd
import os.path
from tqdm import tqdm
from mdataset.utils.item import Item, ItemFileWrite

from mdataset.psql_base import PSQLBase, DSType

# The PSQL class provides methods for uploading and downloading meteorite and Roche images to and from
# a PostgreSQL database, as well as extracting metadata and retrieving class information.


class PSQL(PSQLBase):

    def __init__(self, host="localhost", port=5432):
        super().__init__(host, port, "rocknet")
        self.user = "rocknet"
        self.password = "rocknet!2023"

    def create_table(self):
        query_roche = """CREATE TABLE IF NOT EXISTS roche(
                         name text NOT NULL,
                         image bytea NOT NULL,
                         md5 uuid UNIQUE NOT NULL,
                         quality text
                        )"""
        query_dataset = """CREATE TABLE IF NOT EXISTS dataset(
                         version_number text,
                         version_type text,
                         classe text,
                         type text,
                         quality text,
                         md5 uuid NOT NULL
                        )"""
        cur = self.conn.cursor()
        cur.execute(query_roche)
        cur.execute(query_dataset)
        self.conn.commit()

    def upload_roche_dataset_from_csv(self, root_path: str, csv_file: str, version_number: str, version_type=None):
        """Uploads Roche images and dataset to the database from a CSV file containing the image paths and metadata.
        The CSV file must contain the following columns: class, dataType, quality, image, md5.
        Where dataType is the type of the image (train, test, validation).
            quality is the quality of the image (Premium,Acceptable,Etrange, can be empty).
            image is the name of the image.
        """
        cur = self.conn.cursor()

        # Check if the dataset already exists
        check_query = """SELECT COUNT(*) FROM dataset WHERE version_number = %s AND version_type = %s;"""
        cur.execute(check_query, (version_number, version_type))
        dataset_exists = cur.fetchone()[0] > 0

        if dataset_exists:
            print("Dataset already exists. Skipping upload.")
            return

        query_md5 = """SELECT md5 FROM roche;"""
        cur.execute(query_md5)

        liste_md5 = [uuid.UUID(m[0]) for m in cur.fetchall()]

        query = """INSERT INTO roche (name,image,md5,quality)
                    VALUES (%s,%s,%s,%s);"""

        df = pd.read_csv(os.path.join(root_path, csv_file), sep=",")

        for _, row in df.iterrows():
            kind = row["class"]
            d_type = row["dataType"]
            quality = row["quality"]
            image = row["image"]
            md5 = row["md5"]
            filename = os.path.join(root_path, kind, quality, image)
            if uuid.UUID(md5) not in liste_md5:
                with open(filename, "rb") as f:
                    img = f.read()
                cur.execute(query, (image, psycopg2.Binary(img), md5, quality))
            if version_type:
                query_data = """INSERT INTO dataset (version_number,version_type,classe,type,quality,md5)
                        VALUES (%s,%s,%s,%s,%s,%s)"""
                cur.execute(query_data, (version_number, version_type, kind, d_type, quality, md5))
            else:
                query_insert = """INSERT INTO dataset (version_number, version_type, classe, type, quality, md5)
                                        VALUES (%s, NULL, %s, %s, %s, %s)"""
                cur.execute(query_insert, (version_number, kind, d_type, quality, md5))

        self.conn.commit()

    def upload_roche_from_csv(self, root_path: str, csv_file: str):
        """Uploads Roche images to the database from a CSV file containing the image paths and metadata.
        The CSV file must contain the following columns: image, path, md5, quality.
        Where quality is the quality of the image (Premium,Acceptable,Etrange, can be empty).
              image is the name of the image."""

        cur = self.conn.cursor()

        query_md5 = """SELECT md5 FROM roche;"""
        cur.execute(query_md5)

        liste_md5 = [uuid.UUID(m[0]) for m in cur.fetchall()]

        query = """INSERT INTO roche (name,image,md5,quality)
                    VALUES ('{0}',{1},'{2}','{3}');"""

        df = pd.read_csv(os.path.join(root_path, csv_file), sep=",")
        for _, row in df.iterrows():
            image = row["image"]
            filename = os.path.join(root_path, row["path"])
            md5 = row["md5"]
            quality = row["quality"]
            if uuid.UUID(md5) not in liste_md5:
                with open(filename, "rb") as f:
                    img = f.read()
                cur.execute(query.format(image, pg.Binary(img), md5, quality))
        self.conn.commit()

    def num_samples(self, version_number, version_type=None, type="train"):
        # Query to count the number of entries for each class
        query_count = "SELECT COUNT(md5) FROM dataset WHERE version_number = %s AND type = %s"

        if version_type is None or len(version_type) == 0:
            query_count += " AND version_type IS NULL"
        else:
            query_count += " AND version_type = %s"

        params = [version_number, type]
        if version_type is not None and len(version_type) > 0:
            params.append(version_type)
        with self.conn.cursor() as cur:
            cur.execute(query_count, params)
            row = cur.fetchone()

        return row[0]

    def classes(self, version_number, version_type=None):
        # Base query to get distinct classes
        query = "SELECT DISTINCT classe FROM dataset WHERE version_number = %s"

        # Append condition for version_type if it's not None
        params = [version_number]
        if version_type is None or len(version_type) == 0:
            query += " AND version_type IS NULL"
        else:
            query += " AND version_type = %s"
            params.append(version_type)

        query += " ORDER BY classe"

        classes = []
        with self.conn.cursor() as cur:
            cur.execute(query, params)
            for c in cur:
                classes.append(c[0])
        return classes

    def download_dataset(self, version_number, version_type=None, type="train", output_folder=None):
        # Base query
        query = """SELECT image, dataset.classe
                FROM roche
                JOIN dataset ON roche.md5 = dataset.md5
                WHERE version_number = %s AND type = %s"""

        # Append additional condition for version_type if it's not None
        params = [version_number, type]
        if version_type is None or len(version_type) == 0:
            version_type = ""
            query += " AND version_type IS NULL"
        else:
            query += " AND version_type = %s"
            params.append(version_type)

        query += " ORDER BY roche.name"

        # Ensure the output folder exists
        if output_folder is None:
            output_folder = os.path.join("rocknet_ds", version_number, str(version_type))
        os.makedirs(output_folder, exist_ok=True)

        # Save the entire dataset to a lmdb folder
        if version_type is None or len(version_type) == 0:
            output_file = os.path.join(output_folder, f"{version_number}_{type}")
        else:
            output_file = os.path.join(output_folder, f"{version_number + ' ' + version_type}_{type}")

        print(f"download {output_file}")

        num_samples = self.num_samples(version_number, version_type, type)
        classes = self.classes(version_number, version_type)

        # Curseur est géré côté serveur,
        # ce qui évite de charger tous les résultats en mémoire sur le client.
        valid_samples = 0
        with ItemFileWrite(basename=output_file) as file:
            
            cur = self.conn.cursor(name="images_cursor")
            cur.execute(query, params)

            file.meta_data['classes'] = classes

            for i, r in tqdm(enumerate(cur), total=num_samples):
                try:
                    img = Image.open(io.BytesIO(r[0]))
                    classe = r[1]

                    item = Item(
                        np.array(img.convert("RGB")), 
                        rock_type=classes.index(classe)
                        )
                    file.write(item)
                    valid_samples += 1

                except Exception as e:
                    print(f"An error occurred while processing image {i}: {e}")

            if valid_samples != num_samples:
                print(f"only {valid_samples} for {num_samples} are found !")

            cur.close()

        return output_file

    def create_dataset(self, version_number, version_type, csv):
        """Create a dataset from a csv file containing the metadata of the images.
        The csv file must contain the following columns : class, dataType, quality, md5.
        Where dataType is the type of the image (train, test, validation).
              quality is the quality of the image (Premium,Acceptable,Etrange, can be empty).
              md5 is the md5 of the image."""

        query = """SELECT md5
                FROM roche"""

        df = pd.read_csv(csv)
        l = df.values.tolist()
        with self.conn.cursor() as cur:
            cur.execute(query)
            roche = cur.fetchall()
            for i in range(len(l)):
                for j in range(len(roche)):
                    if roche[j][0] == l[i][-1]:
                        if version_type:
                            query_insert = """INSERT INTO dataset (version_number, version_type, classe, type, quality, md5)
                                            VALUES (%s, %s, %s, %s, %s, %s)"""
                            params = (version_number, version_type, l[i][1], l[i][2], l[i][3], roche[i][0])
                        else:
                            query_insert = """INSERT INTO dataset (version_number, version_type, classe, type, quality, md5)
                                          VALUES (%s, NULL, %s, %s, %s, %s)"""
                            params = (version_number, l[i][1], l[i][2], l[i][3], roche[i][0])
                        cur.execute(query_insert, params)

        psql.conn.commit()


if __name__ == "__main__":
    with PSQL(host="10.25.11.36") as psql:
        print("Connected to PostgreSQL database")
        # psql.upload_roche_from_csv(r'D:\projets\dataset\data\2-DataSetFull_v2_trié_nettoyé -12 2023','roche_trie_nettoye.csv')
        # psql.create_dataset('1.0 Test',r'D:\projets\dataset\data\roche_trie_nettoye_test.csv')
        # print('done')
        # psql.upload_roche_dataset_from_csv(r'D:\projets\dataset\data\2-DataSetFull_v2_trié -12 2023','exemple_roche.csv','test')
        psql.download_dataset(version_number="0.0", type="train")
        psql.download_dataset(version_number="0.0", type="test")
        psql.download_dataset(version_number="0.0", type="val")
        print(psql.num_samples(version_number="0.0", type="train"))
        # print(psql.get_classe(version_number='0.0', type='val'))
        # psql.create_table()
        # root_path = r'data\2-DataSetFull_v2_trié -12 2023'
        # csv = r'data\roche.csv'
        # psql.upload_roche_from_csv(root_path, csv)
        # version = "default"
        # psql.donwload_dataset('default','train')
        # psql.create_dataset('default')
