import os.path
from typing import Any
from torchvision.datasets.vision import VisionDataset
import hashlib
from mdataset.rocknet.psql import PSQL, DSType
from mdataset.utils.item import ItemFileRead
from PIL import Image


class RockNet(VisionDataset):
    default = "default"
    files_list = {
        "0.0": [
            ("0.0_train", "c4dfb85c5a8917259520bb099cc5e9ff"),
            ("0.0_test", "bc93b2042e9bbfb0a72cbf2ac6dc8fa0"),
            ("0.0_val", "919202ca24ec1d3adaffd18430b91e6a"),
        ],
        "1.0": [
            ("1.0_train", "4f384d41952883063b71a14235c239fb"),
            ("1.0_test", "6ba626fed799abc612fda01ce18b0b11"),
            ("1.0_val", "82948be9b7b35559279864468e327391"),
        ],
        "1.0 Premium": [
            ("1.0 Premium_train", "95f35743e5e2519693cc3bef7aafa6e8"),
            ("1.0 Premium_test", "8e4b52d2a7a541faab95e1e97e647a62"),
            ("1.0 Premium_val", "b54cbc689323c95a83fa92fd7ae2ee67"),
        ],
        "1.0 Premium Acceptable": [
            ("1.0 Premium Acceptable_train", "cc6dfe85ed7bb36959aaae1ca5d8949b"),
            ("1.0 Premium Acceptable_test", "d1322f509da82f2f8ec605067fdbc6c3"),
            ("1.0 Premium Acceptable_val", "3bcbfdf59d5033c692e41337ba8dc298"),
        ],
        "1.0 Abdallah": [
            ("1.0 Abdallah_train", "541328de0ce88ab4a565edc03dfbbb42"),
            ("1.0 Abdallah_test", "212f7d0b397c5a61858dc7f7a27d3511"),
            ("1.0 Abdallah_val", "c7ecd0aae6d683edd17209b93826324e"),
        ],
    }

    @property
    def base_folder(self):
        return os.path.join(self.root, "rocknet_ds", self.version_number, self.version_type)

    @property
    def download_folder(self):
        return os.path.join(self.root, "rocknet_ds", self.version_number)

    def __init__(
        self,
        root: str,
        type: DSType = DSType.TRAIN,
        transform: callable = None,
        download: bool = False,
        version_number: str = "default",
        version_type: str = "default",
        host: str = "IRLINV-R11DB",
        port: int = 5432,
    ) -> None:

        super().__init__(root, transform=transform)
        self.host = host
        self.port = port
        if version_number == "default":
            self.version_number = "0.0"
        else:
            self.version_number = version_number

        if version_type == "default" or version_type == "" or version_type == None or version_type == "None":
            self.version_type = ""
            self.version_type_with_space = ""
        else:
            self.version_type = version_type
            self.version_type_with_space = " " + self.version_type

        if (self.version_number + self.version_type_with_space) not in self.files_list:
            raise RuntimeError(f"No dataset defined with this version {self.version_number + self.version_type_with_space}")

        if download:
            self.download()

        self.type = DSType(type)
        if self.type == DSType.TRAIN:
            ds_file = f"{self.version_number + self.version_type_with_space}_train"
        elif self.type == DSType.TEST:
            ds_file = f"{self.version_number + self.version_type_with_space}_test"
        elif self.type == DSType.VALID:
            ds_file = f"{self.version_number + self.version_type_with_space}_val"
        else:
            raise RuntimeError(f"Not valid dataset type {self.type}")

        self.data_file = os.path.join(self.base_folder, ds_file)

        self._load_metadata_()

    def _load_metadata_(self) -> None:
        """
        This function loads metadata from a PostgreSQL database and creates a dictionary mapping class
        labels to their corresponding indices.
        """
        self.reader = ItemFileRead(basename=self.data_file)

        if not os.path.exists(self.reader.hdr_name):
            raise "Dataset not exists or corrupted. Try with option download=True"

        self.classes = self.reader.meta_data["classes"]
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}

    @property
    def n_classes(self):
        return len(self.classes)

    def __getitem__(self, index: int):
        """
        This function returns a tuple of an image and its corresponding target label from a dataset, with
        optional transformations applied to the image.

        :param index: The index of the item to retrieve from the dataset
        :type index: int
        :return: A tuple containing the transformed image and its corresponding target label.
        """
        item = self.reader.read(index)

        img = Image.fromarray(item.array)
        if self.transform is not None:
            img = self.transform(img)

        return img, item.rock_type

    def __len__(self) -> int:
        return len(self.reader)

    def _check_integrity(self) -> bool:
        """
        This function checks the integrity of files in a dataset by comparing their MD5 checksums.
        :return: A boolean value is being returned.
        """

        for fentry in RockNet.files_list[self.version_number + self.version_type_with_space]:
            filename, expected_md5 = fentry
            fpath = os.path.join(self.base_folder, f"{filename}.bin")
            try:
                file_md5 = compute_md5(fpath)
                if file_md5 != expected_md5:
                    print(f"File {filename} failed MD5 check: expected {expected_md5}, got {file_md5}")
                    return False
            except Exception as e:
                print(f"Exception occurred while checking file {filename}: {e}")
                return False
        return True

    def download(self):
        """
        This function downloads the dataset from a PostgreSQL database in LMDB format and checks its integrity.
        :return: Nothing is being returned explicitly in this code. However, the function may return
        early with the message "Files already downloaded and verified" if the integrity check passes.
        """
        print("Download enabled, check integrity")
        if self._check_integrity():
            print("Files already downloaded and verified")
            return

        folder = self.base_folder
        os.makedirs(folder, exist_ok=True)
        downloaded_files = []

        with PSQL(host=self.host, port=self.port) as psql:
            train_file = psql.download_dataset(
                version_number=self.version_number, version_type=self.version_type, type="train", output_folder=folder
            )
            downloaded_files.append(train_file)
            test_file = psql.download_dataset(
                version_number=self.version_number, version_type=self.version_type, type="test", output_folder=folder
            )
            downloaded_files.append(test_file)
            val_file = psql.download_dataset(
                version_number=self.version_number, version_type=self.version_type, type="val", output_folder=folder
            )
            downloaded_files.append(val_file)

        print("Datasets downloaded successfully")
        print("List of downloaded files with their MD5 checksums:")

        print(downloaded_files)
        for file_path in downloaded_files:
            file_uuid = compute_md5(f"{file_path}.bin")
            print(f"{file_path}.bin: {file_uuid}")

        if not self._check_integrity():
            raise RuntimeError("Download failed... integrity is corrupted")


def compute_md5(file_path):
    # Initialiser l'objet md5
    md5_hash = hashlib.md5()

    # Lire le fichier en mode binaire et mettre à jour le hash
    with open(file_path, "rb") as f:
        # Lire le fichier par morceaux (par exemple, 4096 octets à la fois)
        for chunk in iter(lambda: f.read(4096), b""):
            md5_hash.update(chunk)

    # Retourner le hash en format hexadécimal
    return md5_hash.hexdigest()


if __name__ == "__main__":

    import matplotlib.pyplot as plt

    r = RockNet(
        "data",
        type="train",
        transform=None,
        version_number="1.0",
        version_type="Abdallah",
        download=True,
        # host="IRLINV-R11DB",
    )

    print(len(r))

    img, idx = r[0]
    print(type(idx))

    # mlt.rcParams['backend'] = "TkAgg"
    plt.imshow(img)
    plt.show()

    print(r.class_to_idx)
