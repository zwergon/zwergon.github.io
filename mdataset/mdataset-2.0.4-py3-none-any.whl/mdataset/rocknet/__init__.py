import os.path
from typing import Any
from torchvision.datasets.vision import VisionDataset
import hashlib
from mdataset.rocknet.psql import PSQL, DSType
from mdataset.utils.item import ItemFileRead
from PIL import Image


class RockNet(VisionDataset):
    default = "default"
    files_list = {
        "0.0": [
            ("0.0_train", "1f409f6e4a154ab1a0cac7a8627a4d23"),
            ("0.0_test", "6bbed2de81de29b02908a1f4388e6103"),
            ("0.0_val", "82fe5a1f9eaa7f934596a139a0438dc8"),
        ],
        "1.0": [
            ("1.0_train", "4b94fdfc9f8b98d3e91fc5afceca41f1"),
            ("1.0_test", "d05565df32ca4efac5c389e4db4f566c"),
            ("1.0_val", "4d0ab6fc9869fa666c9cd553940d3bf5"),
        ],
        "1.0 Premium": [
            ("1.0 Premium_train.hdf5", "f58ef3c7dc67c711f1056ddad026377e"),
            ("1.0 Premium_test.hdf5", "6a7b28b1e1814d5e84ce471258a3efee"),
            ("1.0 Premium_val.hdf5", "913ea4aae829fd92ec71743dc11b581c"),
        ],
        "1.0 Premium Acceptable": [
            ("1.0 Premium Acceptable_train.hdf5", "784a44956e998587c3b1337ffd23f80e"),
            ("1.0 Premium Acceptable_test.hdf5", "5a2fe6abbd754e079f18ae680d6a55c5"),
            ("1.0 Premium Acceptable_val.hdf5", "70c85b2a7f66b9c710be03e761fe5c53"),
        ],
        "1.0 Abdallah": [
            ("1.0 Abdallah_train", "9ada521137c18b9ee448dace89992354"),
            ("1.0 Abdallah_test", "b19b9030a942665eefd7bfcb6c8be6c1"),
            ("1.0 Abdallah_val", "51ee6c7b8a3a07a4069a68eb7a968a68"),
        ],
    }

    @property
    def base_folder(self):
        return os.path.join(self.root, "rocknet_ds", self.version_number, self.version_type)

    @property
    def download_folder(self):
        return os.path.join(self.root, "rocknet_ds", self.version_number)

    def __init__(
        self,
        root: str,
        type: DSType = DSType.TRAIN,
        transform: callable = None,
        download: bool = False,
        version_number: str = "default",
        version_type: str = "default",
        host: str = "localhost",
        port: int = 5432,
    ) -> None:

        super().__init__(root, transform=transform)
        self.host = host
        self.port = port
        if version_number == "default":
            self.version_number = "0.0"
        else:
            self.version_number = version_number

        if version_type == "default":
            self.version_type = ""
            self.version_type_with_space = ""
        else:
            self.version_type = version_type
            self.version_type_with_space = " " + self.version_type

        if (self.version_number + self.version_type_with_space) not in self.files_list:
            raise RuntimeError(f"No dataset defined with this version {self.version_number + self.version_type_with_space}")

        if download:
            self.download()

        self.type = DSType(type)
        if self.type == DSType.TRAIN:
            ds_file = f"{self.version_number + self.version_type_with_space}_train"
        elif self.type == DSType.TEST:
            ds_file = f"{self.version_number + self.version_type_with_space}_test"
        elif self.type == DSType.VALID:
            ds_file = f"{self.version_number + self.version_type_with_space}_val"
        else:
            raise RuntimeError(f"Not valid dataset type {self.type}")

        self.data_file = os.path.join(self.base_folder, ds_file)

        self._load_metadata_()

    def _load_metadata_(self) -> None:
        """
        This function loads metadata from a PostgreSQL database and creates a dictionary mapping class
        labels to their corresponding indices.
        """
        self.reader = ItemFileRead(basename=self.data_file)

        if not os.path.exists(self.reader.hdr_name):
            raise "Dataset not exists or corrupted. Try with option download=True"

        self.classes = self.reader.meta_data["classes"]
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}

    @property
    def n_classes(self):
        return len(self.classes)

    def __getitem__(self, index: int):
        """
        This function returns a tuple of an image and its corresponding target label from a dataset, with
        optional transformations applied to the image.

        :param index: The index of the item to retrieve from the dataset
        :type index: int
        :return: A tuple containing the transformed image and its corresponding target label.
        """
        item = self.reader.read(index)

        img = Image.fromarray(item.array)
        if self.transform is not None:
            img = self.transform(img)

        return img, item.rock_type

    def __len__(self) -> int:
        return len(self.reader)

    def _check_integrity(self) -> bool:
        """
        This function checks the integrity of files in a dataset by comparing their MD5 checksums.
        :return: A boolean value is being returned.
        """

        for fentry in RockNet.files_list[self.version_number + self.version_type_with_space]:
            filename, expected_md5 = fentry
            fpath = os.path.join(self.base_folder, f"{filename}.bin")
            try:
                file_md5 = compute_md5(fpath)
                if file_md5 != expected_md5:
                    print(f"File {filename} failed MD5 check: expected {expected_md5}, got {file_md5}")
                    return False
            except Exception as e:
                print(f"Exception occurred while checking file {filename}: {e}")
                return False
        return True

    def download(self):
        """
        This function downloads the dataset from a PostgreSQL database in LMDB format and checks its integrity.
        :return: Nothing is being returned explicitly in this code. However, the function may return
        early with the message "Files already downloaded and verified" if the integrity check passes.
        """
        print("Download enabled, check integrity")
        if self._check_integrity():
            print("Files already downloaded and verified")
            return

        folder = self.base_folder
        os.makedirs(folder, exist_ok=True)
        downloaded_files = []

        with PSQL(host=self.host, port=self.port) as psql:
            train_file = psql.download_dataset(
                version_number=self.version_number, version_type=self.version_type, type="train", output_folder=folder
            )
            downloaded_files.append(train_file)
            test_file = psql.download_dataset(
                version_number=self.version_number, version_type=self.version_type, type="test", output_folder=folder
            )
            downloaded_files.append(test_file)
            val_file = psql.download_dataset(
                version_number=self.version_number, version_type=self.version_type, type="val", output_folder=folder
            )
            downloaded_files.append(val_file)

        print("Datasets downloaded successfully")
        print("List of downloaded files with their MD5 checksums:")

        print(downloaded_files)
        for file_path in downloaded_files:
            file_uuid = compute_md5(f"{file_path}.bin")
            print(f"{file_path}.bin: {file_uuid}")

        if not self._check_integrity():
            raise RuntimeError("Download failed... integrity is corrupted")


def compute_md5(file_path):
    # Initialiser l'objet md5
    md5_hash = hashlib.md5()

    # Lire le fichier en mode binaire et mettre à jour le hash
    with open(file_path, "rb") as f:
        # Lire le fichier par morceaux (par exemple, 4096 octets à la fois)
        for chunk in iter(lambda: f.read(4096), b""):
            md5_hash.update(chunk)

    # Retourner le hash en format hexadécimal
    return md5_hash.hexdigest()


if __name__ == "__main__":

    import matplotlib.pyplot as plt

    r = RockNet(
        "data",
        type=0,
        transform=None,
        version_number="0.0",
        # version_type='Premium',
        download=True,
        host="10.25.11.36",
    )

    print(len(r))

    img, idx = r[0]
    print(type(idx))

    # mlt.rcParams['backend'] = "TkAgg"
    plt.imshow(img)
    plt.show()

    print(r.class_to_idx)
