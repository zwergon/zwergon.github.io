"""_summary_
    This code is renaming files in a directory by replacing special characters with their corresponding
ASCII characters using the `unidecode` function from the `unidecode` module. The code first defines
the path and then loops through the files. For each file, it replaces any occurrence of the degree symbol (`°`)
with a space, and then applies the `unidecode` function to convert any other special characters to
their ASCII equivalents. Finally, it renames the file with the new name.
"""


import glob
import os
from unidecode import unidecode

if __name__ == "__main__":

    root_dir = r'D:\projets\dataset\data\2-DataSetFull_v2_trié -12 2023'

    for dirpath, dirnames, filenames in os.walk(root_dir):
        for dir in dirnames :
            sub_dir = os.path.join(dirpath,dir)
            print(sub_dir)
            for dir_ in os.walk(sub_dir) :
                for d in dir_[1] :
                        sub_dir_ = os.path.join(sub_dir,d)
                        for filename in os.walk(sub_dir_) :
                            for f in filename[2] :
                                oldername = f
                                olderpath = os.path.join(filename[0],oldername)
                                newname = unidecode(f)
                                newnpath = os.path.join(filename[0], newname)
                                if newnpath != olderpath :
                                    os.rename(olderpath,newnpath)
    print("done")
