
from struct import *
import numpy as np
import bson 

def dtype_to_char(t):
    return {
        'int8': 'b',
        'uint8': 'B',
        'int16': 'h',
        'uint16': 'H',
        'int32': 'i',
        'uint32': 'I',
        'int64': 'l',
        'uint64': 'L',
        'float32': 'f',
        'float64': 'd'
    }[t.name]

def char_to_dtype(c):
    return {
        'b': 'int8',
        'B': 'uint8',
        'h': 'int16',
        'H': 'uint16',
        'i': 'int32',
        'I': 'uint32',
        'l': 'int64',
        'L': 'uint64',
        'f': 'float32',
        'd': 'float64'
    }[c.decode()]


def str_to_bytes(msg: str):
    encoded = msg.encode(encoding='utf-8')
    l = len(encoded)
    return pack('>i', l) + encoded, l+4
        
def bytes_to_str(barray: bytearray):
    l = unpack('>i', barray[:4])[0]
    encoded = barray[4:4+l]
    msg = encoded.decode(encoding='utf-8')
    return msg, l
    

class Item:

    HDR_SIZE = 17

    @staticmethod
    def from_bytes(barray):

        hdr = unpack('<cLLLi', barray[:Item.HDR_SIZE])
        array = np.frombuffer(
            buffer=barray[Item.HDR_SIZE:], 
            dtype=np.dtype(char_to_dtype(hdr[0]))).reshape(hdr[1:-1])
        rock_type = hdr[-1]
        item = Item(array, rock_type)
        return item

    def __init__(self, array: np.array, rock_type = -1) -> None:
        self.rock_type = rock_type
        self.array = array
    
    def to_bytes(self):
        t = dtype_to_char(self.array.dtype)
        hdr = pack('<cLLLi', t.encode(),  
                   self.array.shape[0],
                   self.array.shape[1],
                   self.array.shape[2],
                   self.rock_type 
                   )
        
        # take care, further work may be done to avoid direct use of tobytes method that may be 
        # platform dependant. 
        barray = hdr + self.array.tobytes()     
        return barray, len(barray) 
        

class ItemFile:
    def __init__(self, basename) -> None:
        self.basename = basename
        self.meta_data = {
            "items": []
        }

    @property
    def bin_name(self):
        return f"{self.basename}.bin"
    
    @property
    def hdr_name(self):
        return f"{self.basename}.hdr"


class ItemFileWrite(ItemFile):

    def __init__(self, basename) -> None:
        super().__init__(basename)
        self.data_file = None
        self.offset = 0

    def __enter__(self):
        self.data_file = open(self.bin_name, 'wb')
        self.offset = 0
        return self
    
    def write(self, item: Item):
        b_array, l = item.to_bytes()
        self.meta_data['items'].append( (self.offset, l) )
        self.data_file.seek(self.offset)
        self.data_file.write(b_array)
        self.offset += l
        
    def __exit__(self, exc_type, exc_value, exc_traceback):
        with open(self.hdr_name, "wb") as f:
            a = bson.dumps(self.meta_data)
            f.write(a)
        self.data_file.close()


class ItemFileRead(ItemFile):

    def __init__(self, basename) -> None:
        super().__init__(basename)
        with open(self.hdr_name, 'rb') as f:
            buffer = f.read()
            self.meta_data = bson.loads(buffer)
        # create numpy array to speed up lookup of offsets
        self.offsets = np.array(self.meta_data['items'])
    
    def __len__(self):
        return len(self.meta_data['items'])
    
    def read(self, idx):
        offset = self.offsets[idx]
        with open(self.bin_name, 'rb') as f:
            f.seek(offset[0])
            b_array = f.read(offset[1])        
        item = Item.from_bytes(barray=b_array)
        
        return item
        
    
