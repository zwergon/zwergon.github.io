import hashlib
import os
import uuid
import lmdb

def extract_and_sort_data(lmdb_path):
    env = lmdb.open(lmdb_path, readonly=True)
    data_list = []

    with env.begin() as txn:
        cursor = txn.cursor()
        for key, value in cursor:
            # Append tuples of (key, value) to the list
            data_list.append((key, value))

    # Sort the list of tuples by key
    sorted_data = sorted(data_list, key=lambda x: x[0])
    return sorted_data

def compute_custom_hash(lmdb_folder_path):
    data = extract_and_sort_data(lmdb_folder_path)
    hash_md5 = hashlib.md5()

    for key, value in data:
        # Update the hash with key and value
        hash_md5.update(key)
        hash_md5.update(value)

    return hash_md5.hexdigest()

def compute_lmdb_folder_uuid(lmdb_folder_path):
    hash_md5 = hashlib.md5()
    
    for root, dirs, files in os.walk(lmdb_folder_path):
        dirs.sort()
        for file in files:
            if file == "data.mdb":
                file_path = os.path.join(root, file)
                print(f"Processing {file_path}")
                
                with open(file_path, "rb") as f:
                    for chunk in iter(lambda: f.read(8192), b""):
                        hash_md5.update(chunk)
    
    # Convert the final MD5 hash to a UUID
    return str(uuid.UUID(hash_md5.hexdigest()))


if __name__ == "__main__":
    print(compute_lmdb_folder_uuid(r"D:\psql_data\rocknet_ds\0.0\0.0_test"))
    print(compute_custom_hash(r"D:\psql_data\rocknet_ds\1.0\Premium\1.0 Premium_test"))