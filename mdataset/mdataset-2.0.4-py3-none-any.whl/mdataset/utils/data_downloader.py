import socket
import os
import tarfile
import io

def receive_file(conn, output_dir):
    tar_stream = io.BytesIO()
    while True:
        data = conn.recv(4096)
        if b"DONE" in data:
            tar_stream.write(data.replace(b"DONE", b''))
            break
        tar_stream.write(data)

    tar_stream.seek(0)
    with tarfile.open(fileobj=tar_stream, mode='r:gz') as tar:
        tar.extractall(path=output_dir)

def download_dataset(dataset_path, download_dir,host='10.25.11.36',port=5001):
    os.makedirs(download_dir, exist_ok=True)
    normalized_path = dataset_path.replace('\\', '/')
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))
    print(f"Connected to {host}:{port}")

    client_socket.sendall(normalized_path.encode())

    response = client_socket.recv(1024).decode().strip()
    if response == "READY":
        receive_file(client_socket, download_dir)
        print("Download completed.")
    else:
        print(f"Error: {response}")

    client_socket.close()
