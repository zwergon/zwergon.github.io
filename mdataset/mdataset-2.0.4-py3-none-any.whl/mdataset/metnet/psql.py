import PIL.Image as Image
import io
import hashlib
import uuid
import os.path

import pandas as pd
import numpy as np

from psycopg2 import errors
import psycopg2 as pg
from psycopg2.errorcodes import UNIQUE_VIOLATION


from mdataset.psql_base import PSQLBase

# The PSQL class provides methods for uploading and downloading meteorite and Roche images to and from
# a PostgreSQL database, as well as extracting metadata and retrieving class information.
class PSQL(PSQLBase) :

    def __init__(self, host = 'localhost', port = 5431) :
        super(PSQL, self).__init__(host, port, "metnet")

        self.user = "metnet"
        self.password = "metnet!2023"
        
    def create_table(self) :
        query_met = "CREATE TABLE IF NOT EXISTS meteorite(" \
                    "name varchar(50) NOT NULL," \
                    "classe varchar(50)," \
                    "source varchar(50)," \
                    "image bytea NOT NULL," \
                    "md5 uuid UNIQUE NOT NULL)"
        
        query_roche = "CREATE TABLE IF NOT EXISTS roche(" \
                       "name varchar(50) NOT NULL," \
                       "image bytea NOT NULL," \
                       "md5 uuid UNIQUE NOT NULL)"
        
        query_dataset = "CREATE TABLE IF NOT EXISTS dataset(" \
                       "md5 uuid NOT NULL," \
                       "version text," \
                       "type text," \
                       "label text)"
        
        cur = self.conn.cursor()
        cur.execute(query_met)
        cur.execute(query_roche)
        cur.execute(query_dataset)
        self.conn.commit()
        
    def upload_met(self,name,classe,path,source) :
        """
        This function uploads a meteorite image to a database along with its name, class, source, and MD5
        hash.
        
        :param name: The name of the meteorite being uploaded
        :param classe: The class of the meteorite
        :param path: The path to the image file that will be uploaded
        :param source: The source of the meteorite data or information being uploaded
        """
        query = """INSERT INTO meteorite (name,classe,source,image,md5)
                    VALUES (%s,%s,%s;%s);"""
        
        try :
            cur = self.conn.cursor()
            with open(path,"rb") as f :
                img = f.read()
                md5_hash = hashlib.md5(img).hexdigest()
                cur.execute(query,(name,classe,source,img,md5_hash))
        except errors.lookup(UNIQUE_VIOLATION) as err :
            print(err)
        self.conn.commit()

    def upload_met_from_csv(self,csv) :
        """
        This function uploads meteorite data from a CSV file to a database, including the meteorite name,
        file path, image as binary data, and MD5 hash.
        
        :param csv: The parameter "csv" is a file path to a CSV file containing data about meteorites,
        including their names, file paths to their images, and MD5 hash values. The function reads this CSV
        file and uploads the data to a PostgreSQL database table called "meteorite"
        """
        query = """INSERT INTO meteorite (name,classe,image,md5)
                    VALUES ('{0}','{1}',{2},'{3}');"""
        cur = self.conn.cursor()
        df = pd.read_csv(csv)
        l = df.values.tolist()
        for i in range (len(l)) :
            with open(l[i][1],'rb') as f:
                img = f.read()
                cur.execute(query.format(l[i][0],l[i][2],pg.Binary(img),l[i][3]))
        self.conn.commit()

    def upload_roche(self,name,path) :
        """
        This function uploads an image file to a database table named "roche" along with its name, path, and
        MD5 hash.
        
        :param name: The name of the Roche file being uploaded
        :param path: The file path of the Roche image that needs to be uploaded
        """
        query = """INSERT INTO roche (name,image,md5)
                    VALUES (%s,%s,%s);"""
        
        try :
            cur = self.conn.cursor()
            with open(path,"rb") as f :
                img = f.read()
                md5_hash = hashlib.md5(img).hexdigest()
                cur.execute(query,(name,img,md5_hash))
        except errors.lookup(UNIQUE_VIOLATION) as err :
            print(err)
        self.conn.commit()

    def upload_roche_from_csv(self,csv) :
        query = """INSERT INTO roche (name,image,md5)
                    VALUES ('{0}',{1},'{2}');"""
        cur = self.conn.cursor()
        df = pd.read_csv(csv)
        l = df.values.tolist()
        for i in range (len(l)) :
            with open(l[i][1],'rb') as f:
                img = f.read()
                cur.execute(query.format(l[i][0],pg.Binary(img),l[i][2]))
        self.conn.commit()

    def create_datasets (self, sources, version, ratio) :
        query_met = """SELECT md5
                FROM meteorite
                WHERE source ='{0}'
                """
        
        query_roche = """SELECT md5
                FROM roche
                LIMIT {0}
                """
        cur = self.conn.cursor()
            
        if type(sources) is list :
            met = []
            for k in range (len(sources)) :
                cur.execute(query_met.format(sources[k]))
                met+=(cur.fetchall())
        else :
            cur.execute(query_met.format(sources))
            met = cur.fetchall()

        cur.execute(query_roche.format(len(met)))
        roche = cur.fetchall()

        query = """INSERT INTO dataset (md5,version,type,label)
                    VALUES ('{0}','{1}','{2}','{3}');"""
        k=0
        for m in met :
            n = len(met)
            if (k < int(ratio*n)) :
                cur.execute(query.format(m[0],version,'train','meteorite'))
                k+=1
            else :
                cur.execute(query.format(m[0],version,'valid','meteorite'))
                k+=1
        k=0
        for r in roche :
            n = len(roche)
            if (k < int(ratio*n)) :
                cur.execute(query.format(r[0],version,'train','non meteorite'))
                k+=1
            else :
                cur.execute(query.format(r[0],version,'valid','non meteorite'))
                k+=1
        self.conn.commit()

    def get_classe(self,version,type) :
        """
        retrieves a dictionnary with all distinct values for the classes of a dataset
        """
        query = """SELECT distinct(label)
                       FROM dataset
                       WHERE version ='{0}' and type ='{1}';
                    """
        query_ = """SELECT count(md5)
                  FROM dataset
                  WHERE label = '{0}' and version = '{1}' and type='{2}'"""
        cur = self.conn.cursor()
        cur.execute(query.format(version,type))
        rows = cur.fetchall()
        number = []
        for i in rows :
            cur.execute(query_.format(i[0],version,type))
            number.append(cur.fetchall())
        dic = {rows[i][0] : number[i][0][0] for i in range(len(rows))}
        return rows,dic
    
    def extract_meta_data(self, version) :
        """
        construct a dictionnary with all metadata informations
        - size of images # assumes that they all have the same size.
        - classes (what are the classes)
        - train/test dataset size
        """

        meta = {}
        meta["version"] = version
        with self.conn.cursor() as cur :
            query = """SELECT image 
                       FROM meteorite 
                       LIMIT 1"""
            cur.execute(query)
            i = cur.fetchone()
            img = self.to_image(i[0])
            if version in [] :
                img_size = (224,224)
            else :
                img_size = img.size()
            meta["img_size"] = img_size

            
            
    def donwload_dataset(self,version,type) :
        """
        This function downloads a dataset from a database and returns the images and labels.
        
        :param version: The version of the dataset to download
        :param type: The type of dataset to download, which could be either "train", "test", or "validation"
        :return: two numpy arrays: `images` and `labels`. The `images` array contains the images downloaded
        from the database, resized to 224x224 and converted to float32 data type. The `labels` array
        contains the corresponding labels for each image.
        """
        query_met = """SELECT image,dataset.label
                   FROM meteorite
                   JOIN dataset
                   ON meteorite.md5 = dataset.md5
                   WHERE version = '{0}' and type = '{1}'
                   ORDER BY meteorite.name"""
        
        query_roche = """SELECT image,dataset.label
                   FROM roche
                   JOIN dataset
                   ON roche.md5 = dataset.md5
                   WHERE version = '{0}' and type = '{1}'
                   ORDER BY roche.name"""
        
        with self.conn.cursor() as cur :
            cur.execute(query_met.format(version,type))
            met = cur.fetchall()
            cur.execute(query_roche.format(version,type))
            roche = cur.fetchall()

            images = np.zeros(shape=(len(met)+len(roche), 224, 224,3), dtype=np.float32)
            labels = np.zeros(len(met)+len(roche), dtype='<U30')

            for i,l in enumerate(met) :
                img = self.to_image(l[0])
                
                img = img.resize((224,224))
                try :
                    images[i, :, :, :] = np.array(img).astype('float32')
                except :
                    img = img.convert('RGB')
                    images[i, :, :, :] = np.array(img).astype('float32')
                labels[i] = l[1]
            for i,l in enumerate(roche) :
                img = self.to_image(l[0])
                img = img.resize((224,224))
                images[len(met) + i, :, :, :] = np.array(img).astype('float32')
                labels[len(met) +i] = l[1]
        
        return images,labels

        


if __name__ == "__main__":
    with PSQL(host='localhost', port=5431) as psql:
        # psql.create_table()
        # psql.upload_met_from_csv(r'C:\Users\tibarii\Desktop\DB test metnet\met_o.csv')
        # psql.upload_roche_from_csv(r'C:\Users\tibarii\Desktop\DB test metnet\roche_o.csv')
        psql.get_classe('1.0')
        
    
    # folder = os.path.join(os.getcwd(),"MDataset\\2.0")
    # print(folder)
    # os.makedirs(folder)
    # file_list = []
    # with PSQL(host='localhost', port=5431) as psql:
    #     images, labels = psql.donwload_dataset(version='2.0',type = 'train')
    #     # print(labels)
    #     image_file = os.path.join(folder, "train.pkl")
    #     with open(image_file, 'wb') as f:
    #             np.save(f, images)
    #             np.save(f, labels)
    #     file_list.append(("train.pkl", psql.get_md5(image_file)))

    #     images, labels = psql.donwload_dataset(version='2.0',type = 'valid')
    #     image_file = os.path.join(folder, "valid.pkl")
    #     with open(image_file, 'wb') as f:
    #             np.save(f, images)
    #             np.save(f, labels)
        
    #     file_list.append(("valid.pkl", psql.get_md5(image_file)))
    # print("list downloaded files ", file_list)

