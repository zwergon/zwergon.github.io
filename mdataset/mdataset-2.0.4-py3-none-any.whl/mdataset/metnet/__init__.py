import os.path
from typing import Any
import hashlib
import uuid

import numpy as np

import torch
from torchvision.datasets.vision import VisionDataset
from torchvision.datasets.utils import check_integrity
from torch.utils.data import WeightedRandomSampler

from mdataset.metnet.psql import PSQL


# The MetNet class is a subclass of VisionDataset that downloads and loads image datasets from a
# PostgreSQL database, with optional transformations applied to the images.
class MetNet(VisionDataset) :
    
    default = "1.0"
    files_list={
        '1.0':[
            ('train.pkl','55d06aaa-ac87-6ac4-6fa8-6edb9ea4be13'),
            ('valid.pkl', '66f218b0-9f2a-128b-75df-06b0f5810911')
        ],
        '2.0':[
            ('train.pkl','c8c3f1d2-3564-4502-ae49-085f466ab174'),
            ('valid.pkl', '15a5e83d-384e-fdc7-3536-196e7658a725')
        ],
        'test':[
            ('train.pkl','9d23738e-2dd6-c3a6-3c88-6d3e45f618fe'),
            ('valid.pkl', '8ffe3616-953e-da9a-88d7-432ddfc16dc2')
        ]
    }
    @property
    def base_folder(self):
        return "MDataset" +"\\" + self.version

    def __init__(
            self,
            root : str,
            train : bool = True,
            transform : callable = None,
            download: bool = False,
            version: str = "default",
            host: str = 'localhost',
            port: int = 5431
    ) -> None:
    
        super().__init__(root, transform=transform)
        self.host = host
        self.port = port
        if version == 'default' :
            self.version = MetNet.default
        else :
            self.version = version

        if self.version not in self.files_list:
            raise RuntimeError(f"No dataset defined with this version {self.version}")

        if download :
            self.download()
        
        # if not self._check_integrity():
        #     raise RuntimeError("Dataset not found or corrupted. You can use download=True to download it")

        self.train = train  # training set or valid set
        if self.train:
            ds_file = "train.pkl"
            self.type = 'train'
        else:
            ds_file = "valid.pkl"
            self.type = "valid"
        data_file = os.path.join(self.root, self.base_folder, ds_file)
        with open(data_file, 'rb') as f:
            self.data = np.load(f)
            self.targets = np.load(f)
        
        self._load_meta()
    
    def _load_meta(self) -> None:
        """
        This function loads metadata from a PostgreSQL database and creates a dictionary mapping class
        labels to their corresponding indices.
        """
        with PSQL(host=self.host, port=self.port) as psql:
            list_classes,number_classe = psql.get_classe(version=self.version,type=self.type)
            self.classes = list_classes
            self.number_classe = number_classe
        self.class_to_idx = { classe[0]: i for i, classe in enumerate(self.classes)}

    def __getitem__(self, index: int) -> tuple[any,any]:
        """
        This function returns a tuple of an image and its corresponding target label from a dataset, with
        optional transformations applied to the image.
        
        :param index: The index of the item to retrieve from the dataset
        :type index: int
        :return: A tuple containing the transformed image and its corresponding target label.
        """
        img,target = self.data[index],self.targets[index]
        target = self.class_to_idx[target]

        if self.transform is not None:
            img = self.transform(image=img)["image"]

        return img, target

    def __len__(self) -> int:
        return len(self.data)
    
    def _check_integrity(self) -> bool:
        """
        This function checks the integrity of files in a dataset by comparing their MD5 checksums.
        :return: A boolean value is being returned.
        """
        root = self.root

        for fentry in MetNet.files_list[self.version]:
            filename, md5 = fentry[0], fentry[1]
            fpath = os.path.join(root, self.base_folder, filename)
            try :
                with open(fpath,"rb") as f :
                    img = f.read()
                    fpath_uuid = uuid.UUID(hashlib.md5(img).hexdigest())
                if str(fpath_uuid) == md5 :
                    return True
                return False
            except : 
                return False

    
    def download(self) :
        """
        This function downloads and saves two datasets (train and valid) from a PostgreSQL database and
        checks their integrity.
        :return: Nothing is being returned explicitly in this code. However, the function may return
        early with the message "Files already downloaded and verified" if the integrity check passes.
        """
        if self._check_integrity():
            print("Files already downloaded and verified")
            return

        folder = os.path.join(self.root,self.base_folder)
        os.makedirs(folder,exist_ok=True)

        file_list = []
        with PSQL(host=self.host, port=self.port) as psql:
            images, labels = psql.donwload_dataset(version=self.version,type = 'train')
            image_file = os.path.join(folder, "train.pkl")
            with open(image_file, 'wb') as f:
                    np.save(f, images)
                    np.save(f, labels)
            file_list.append(("train.pkl", psql.get_md5(image_file)))

            images, labels = psql.donwload_dataset(version=self.version,type = 'valid')
            image_file = os.path.join(folder, "valid.pkl")
            with open(image_file, 'wb') as f:
                    np.save(f, images)
                    np.save(f, labels)
            
            file_list.append(("valid.pkl", psql.get_md5(image_file)))
            psql.conn.close()
        print("list downloaded files ", file_list)

def create_sampler(train_dataset,flag) :
    """
    This function creates a weighted random sampler for a given training dataset based on the class
    distribution of the dataset.
    
    :param train_dataset: A dataset object containing the training data
    :param flag: A boolean flag that indicates whether to create a weighted sampler or not. If flag is
    True, a weighted sampler will be created based on the class distribution of the target variable in
    the training dataset. If flag is False, a simple random sampler will be created
    :return: The function `create_sampler` returns a `WeightedRandomSampler` object if the `flag`
    parameter is `True`, otherwise it returns `None`.
    """
    if flag :
        y_train = [train_dataset[i][1] for i in range (0,len(train_dataset))]
        class_sample_count = np.array([len(np.where(y_train == t )[0]) for t in np.unique(y_train)])
        weight = 1. / class_sample_count
        samples_weight = np.array([weight[t] for t in y_train])
        samples_weight = torch.from_numpy(samples_weight)
        sampler_tr = WeightedRandomSampler(samples_weight.type('torch.DoubleTensor'), len(samples_weight))
    else :
        sampler_tr = None
    return sampler_tr
