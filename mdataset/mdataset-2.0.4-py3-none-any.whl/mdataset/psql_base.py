
import io
import hashlib
import uuid
import numpy as np

import PIL.Image as Image

from enum import IntEnum

import psycopg2 as pg
from psycopg2.errorcodes import UNIQUE_VIOLATION
from psycopg2 import errors


class DSType(IntEnum):
    TRAIN = 0
    TEST = 1
    VALID = 2

class PSQLBase:

    def __init__(self, host, port, dbname) :
        self.host = host
        self.port = port
        self.database = dbname
        self.user = "postgres"
        self.password = "pg!2023"
        self.conn = None

    def __enter__(self) :
        self.conn = pg.connect(
            database=self.database, 
            user=self.user, 
            password=self.password,
            host=self.host,
            port=self.port)
        return self

    def __exit__(self, *args, **kwargs):
        self.conn.close()
    
    @staticmethod
    def to_image(raw) :
        barray = bytes(raw)
        return Image.open(io.BytesIO(barray))
    
    @staticmethod
    def get_md5(filename) :
        with open(filename,"rb") as f :
            img = f.read()
            return uuid.UUID(hashlib.md5(img).hexdigest())
        
if __name__ == "__main__" :
    with PSQLBase(host='localhost', port=5432, dbname='metnet') as psql:
        print("Connected to PostgreSQL")
