import torch
import torch.nn as nn


class CNNModel(nn.Module):
    def __init__(self, input_size, output_size, config):
        super(CNNModel, self).__init__()

        kernel_size = config["kernel_size"]
        groups = config["groups"]
        self.cnn = nn.Sequential(
            nn.Conv1d(
                input_size, 8, kernel_size=kernel_size, padding="same", groups=groups
            ),
            nn.ReLU(),
            nn.Conv1d(8, 16, kernel_size=kernel_size, padding="same", groups=groups),
            nn.ReLU(),
            nn.Conv1d(16, 32, kernel_size=kernel_size, padding="same", groups=groups),
            nn.ReLU(),
            nn.Conv1d(32, 64, kernel_size=kernel_size, padding="same", groups=groups),
            nn.ReLU(),
            nn.Conv1d(64, 128, kernel_size=kernel_size, padding="same", groups=groups),
        )

        self.layer = nn.Linear(128, output_size)

    def forward(self, x):
        x = self.cnn(x)

        x = torch.swapaxes(x, 1, 2)

        x = self.layer(x)

        x = torch.swapaxes(x, 1, 2)

        return x
