import argparse
import matplotlib.pyplot as plt
import logging

from wbvirtual.utils.config import Config
from wbvirtual.dataset import FileWBDataset


def main_display():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", help="path to parquet file")
    parser.add_argument(
        "-s",
        "--sample",
        help="index of element in the dataset (dataset[sample])",
        type=int,
        default=0,
    )
    parser.add_argument(
        "-sp", "--span", help="range in timeserie to keep [S1, S2]", type=int, nargs=2
    )
    parser.add_argument(
        "-i",
        "--indices",
        help="output indices [0..6] (Default:0)",
        nargs="+",
        type=int,
        default=[0],
    )
    parser.add_argument(
        "-c",
        "--config",
        help="training config file",
        type=str,
        default=Config.default_path(),
    )
    args = parser.parse_args()

    # INPUT Parameters
    config = Config.create_from_args(args)

    dataset = FileWBDataset(
        args.dataset,
        config,
        train_flag=True,
    )

    logging.info(f"train dataset (size) {len(dataset)}")
    logging.info(f".display sample {args.sample}")

    X_idx, y_idx = dataset[args.sample]

    logging.info(f"X_test : {X_idx.shape}")
    logging.info(f"y_test : {y_idx.shape}")

    fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(12, 6))
    fig.suptitle(f"X (solid) versus y (dash) for idx:{args.sample}")

    if args.span is None:
        deb = 0
        end = X_idx.shape[1] - 1
    else:
        deb = args.span[0]
        end = args.span[1]

    for i in range(X_idx.shape[0]):
        ax1.plot(X_idx[i, deb:end], label=f"{dataset.x_columns[i]}")
    ax1.legend()

    for i in range(y_idx.shape[0]):
        ax2.plot(y_idx[i, deb:end], "--", label=f"{dataset.y_selected[i]}")
    ax2.legend()

    plt.show(block=True)
