import argparse
import logging
import matplotlib.pyplot as plt

from torch.utils.data import DataLoader

from wbvirtual.utils.config import Config
from wbvirtual.utils.display import predictions_plot, distrib_plot
from wbvirtual.dataset import FileWBDataset
from wbvirtual.train.training import Training
from wbvirtual.train.feature import Feature

from wbvirtual.post.eq_load import eq_load
from wbvirtual.train.metric_distrib import MetricsDistrib
from sklearn.metrics import r2_score


def main_predict():
    parser = argparse.ArgumentParser()

    parser.add_argument("dataset", help="path to parquet file")
    parser.add_argument("run_id", help="path to checkpoint")
    parser.add_argument(
        "-s",
        "--sample",
        help="index of element in the dataset (dataset[sample])",
        type=int,
        default=0,
    )
    parser.add_argument(
        "-tu",
        "--tracking_uri",
        help="where to find run_id",
        type=str,
        default=None,
    )
    parser.add_argument(
        "-sp", "--span", help="range in timeserie to keep [S1, S2]", type=int, nargs=2
    )
    parser.add_argument(
        "-i",
        "--indices",
        help="output indices [0..6] (Default:0)",
        nargs="+",
        type=int,
        default=[0],
    )

    # INPUT Parameters
    args = parser.parse_args()
    config = Config.create_from_run_id(args.run_id, args.tracking_uri)
    config.cuda = False

    logging.info(config)

    test_dataset = FileWBDataset(args.dataset, config, train_flag=False)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=True)
    _, y_test = next(iter(test_loader))
    logging.info(f"Number of predictions : {len(test_dataset)}")
    logging.info(f"Shape of predictions : {y_test.shape}")

    training = Training(config)
    training.predict(test_loader, run_id=args.run_id)

    if args.span is None:
        deb = 0
        end = training.predictions.actual.shape[2]
    else:
        deb = args.span[0]
        end = args.span[1]

    predictions_plot(training.predictions, index=args.sample, span=[deb, end])

    feature = Feature(eq_load)
    feature.compute(training.predictions, m=3)

    logging.info(f"r2score for DEL: {r2_score(feature.actual, feature.predicted)}")
    fig, axs = plt.subplots(nrows=1, ncols=1)
    fig.suptitle("DEL(s) actual versus predicted")
    axs.scatter(feature.actual, feature.predicted)
    axs.set_xlabel("actual")
    axs.set_ylabel("predicted")

    r2 = MetricsDistrib(r2_score)
    r2.compute(training.predictions)
    distrib_plot(r2.distrib)
    plt.show(block=True)
