from torch.utils.data import DataLoader

from wbvirtual.utils.arguments import parse_args
from wbvirtual.utils.config import Config
from wbvirtual.dataset import FileWBDataset
from wbvirtual.train.training import Training


def main_findlr():
    args = parse_args()

    # INPUT Parameters
    config = Config.create_from_args(args)

    Training.seed(config)

    train_dataset = FileWBDataset(args.dataset, config, train_flag=True)
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers,
    )

    training = Training(config)
    training.find_lr(train_loader=train_loader)


def main_train():
    args = parse_args()

    if args.run_id is not None:
        config = Config.create_from_run_id(args.run_id, args.tracking_uri)
        config.epochs = args.epochs
    else:
        # INPUT Parameters
        config = Config.create_from_args(args)

    Training.seed(config)

    train_dataset = FileWBDataset(args.dataset, config, train_flag=True)
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers,
    )

    test_dataset = FileWBDataset(args.dataset, config, train_flag=False)
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers,
    )

    training = Training(config)
    training.fit(
        train_loader=train_loader, valid_loader=test_loader, run_id=args.run_id
    )
