import ray
import logging
from ray import tune, train
from ray.air import session

from functools import partial

from torch.utils.data import DataLoader
from wbvirtual.utils.config import Config
from wbvirtual.utils.arguments import parse_args
from wbvirtual.dataset import FileWBDataset
from wbvirtual.train.training import Training


class WBTune(Training):
    def __init__(self, config: Config) -> None:
        super().__init__(config)

    def _on_epoch_ended(self, epoch, checkpoint, train_loss, valid_loss):
        session.report({"loss": valid_loss.value})
        return super()._on_epoch_ended(epoch, checkpoint, train_loss, valid_loss)


def tune_parameters(conf, train_loader, valid_loader, config):
    # adjust parameters for our current learning.
    config.learning_rate = conf["learning_rate"]
    config.weight_decay = conf["weight_decay"]
    config.type = conf["type"]
    config.hidden_size = conf["hidden_size"]
    config.num_layers = conf["num_layers"]

    training = WBTune(config)
    training.fit(train_loader, valid_loader)


def main_tune():
    args = parse_args()
    conf = {
        "learning_rate": tune.loguniform(3e-5, 4e-3),
        "weight_decay": tune.loguniform(3e-7, 1e-5),
        "type": tune.choice(["LSTM", "CNN", "GRU", "RNN"]),
        "hidden_size": tune.randint(1, 80),
        "num_layers": tune.randint(1, 8),
    }

    # INPUT Parameters
    config = Config.create_from_args(args)

    Training.seed(config)

    train_dataset = FileWBDataset(args.dataset, config, train_flag=True)

    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers,
    )

    test_dataset = FileWBDataset(args.dataset, config, train_flag=False)

    test_loader = DataLoader(
        test_dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers,
    )

    conf["tracking_uri"] = config.tracking_uri
    ray.init(num_cpus=12, num_gpus=2)

    with_resource = False
    if with_resource:
        trainable = tune.with_resources(
            partial(
                tune_parameters,
                train_loader=train_loader,
                valid_loader=test_loader,
                config=config,
            ),
            {"cpu": 12, "gpu": 2},
        )
    else:
        # use automatic resource management.
        trainable = partial(
            tune_parameters,
            train_loader=train_loader,
            valid_loader=test_loader,
            config=config,
        )

    tuner = tune.Tuner(
        trainable=trainable,
        tune_config=tune.TuneConfig(
            num_samples=100,
            metric="loss",
            mode="min",
        ),
        run_config=train.RunConfig(name="mlflow"),
        param_space=conf,
    )

    result = tuner.fit()

    logging.info(f"Best config: {result.get_best_result(metric='loss', mode='min')}")
