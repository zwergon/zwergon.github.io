import torch.nn as nn


class CNNModel(nn.Module):
    def __init__(self, input_size, output_size, config):
        super(CNNModel, self).__init__()

        kernel_size = config["kernel_size"]
        dropout = config["dropout"]

        self.part1 = nn.Sequential(
            nn.Conv1d(input_size, 8, kernel_size=3, padding="same", groups=4),
            nn.ReLU(),
        )

        self.part2 = nn.Sequential(
            nn.Conv1d(8, 16, kernel_size=3, padding="same", groups=4),
            nn.ReLU()
            )
        
        self.part3 = nn.Sequential(
            nn.Conv1d(16, 32, kernel_size=3, padding="same", groups=4),
            nn.ReLU(),
           
            )
        
        self.part4 = nn.Sequential(
            nn.Conv1d(32, 64, kernel_size=3, padding="same", groups=4),
            nn.ReLU(),
        )

        self.part5 = nn.Sequential(
            nn.Conv1d(64, output_size, kernel_size=3, padding="same"),
        )

        self.maxpool = nn.MaxPool1d(kernel_size=4, stride=2, return_indices=True)
        self.maxunpool = nn.MaxUnpool1d(kernel_size=4, stride=2)

    def forward(self, x):

        x = self.part1(x)

        x, ind = self.maxpool(x)
        x = self.maxunpool(x, ind)

        x = self.part2(x)

        x, ind = self.maxpool(x)
        x = self.maxunpool(x, ind)

        x = self.part3(x)

        x, ind = self.maxpool(x)
        x = self.maxunpool(x, ind)

        x = self.part4(x)

        x, ind = self.maxpool(x)
        x = self.maxunpool(x, ind)

        x = self.part5(x)
        return x
