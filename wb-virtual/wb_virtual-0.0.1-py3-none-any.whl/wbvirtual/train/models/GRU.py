import torch
import torch.nn as nn


# Step 4: Define the LSTM model
class GRUModel(nn.Module):
    def __init__(self, input_size, output_size, config):
        super(GRUModel, self).__init__()
        self.hidden_size = config["hidden_size"]
        self.num_layers = config["num_layers"]

        self.gru = nn.GRU(input_size, self.hidden_size, self.num_layers, batch_first=True)
        self.fc = nn.Linear(self.hidden_size, output_size)
        self.sigmoid = nn.Sigmoid()
        self.tanh = nn.Tanh()

    def forward(self, x):
        x = torch.swapaxes(x, 1, 2)
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        #c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        out, h0 = self.gru(x, h0)
        # out = self.sigmoid(out)
        out = self.fc(out)
        # out = self.sigmoid(out)
        out = torch.swapaxes(out, 1, 2)
        return out 
