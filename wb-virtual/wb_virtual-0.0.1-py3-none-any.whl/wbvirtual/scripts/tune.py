
import ray
from ray import tune, train
from ray.air import  session
from ray.train import ScalingConfig

import mlflow

from functools import partial

from torch.utils.data import DataLoader
from wbvirtual.utils.config import Config
from wbvirtual.utils.arguments import parse_args
from wbvirtual.dataset import FileWBDataset
from wbvirtual.train.training import Training


class WBTune(Training):

    def __init__(self, config: Config) -> None:
        super().__init__(config)

    def _on_epoch_ended(self, epoch, checkpoint, train_loss, valid_loss):
        session.report({"loss":valid_loss.value})
        return super()._on_epoch_ended(epoch, checkpoint, train_loss, valid_loss)
    
def tune_parameters(conf, train_loader, valid_loader, config):
    #adjust parameters for our current learning.
    config.learning_rate = conf['learning_rate']
    config.weight_decay = conf['weight_decay']
   
    training = WBTune(config)
    training.fit(train_loader, valid_loader)



def main_tune():
    args = parse_args()
    conf = {
        "learning_rate": tune.loguniform(3e-5, 1e-2),
        "weight_decay": tune.loguniform(3e-7, 1e-5)
    }
    
    # INPUT Parameters
    config = Config.create_from_args(args)
    
    train_dataset = FileWBDataset(
            args.dataset,
            train_flag=True,
            train_test_ratio=config.ratio_train_test,
            indices=args.indices,
            sensor_desc=config.sensors,
        )

    train_loader = DataLoader(
            train_dataset,
            batch_size=config.batch_size,
            shuffle=True,
            num_workers=config.num_workers,
        )

    test_dataset = FileWBDataset(
            args.dataset,
            train_flag=False,
            train_test_ratio=config.ratio_train_test,
            indices=args.indices,
            sensor_desc=config.sensors,
        )
    test_loader = DataLoader(
            test_dataset,
            batch_size=config.batch_size,
            shuffle=False,
            num_workers=config.num_workers,
        )

    conf['tracking_uri'] = config.tracking_uri
    ray.init(address='auto')

    with_resource = False
    if with_resource:
        trainable = tune.with_resources(
            partial(tune_parameters, train_loader=train_loader, valid_loader=test_loader, config=config),
            {"cpu": 12, "gpu": 1}
        )
    else:
        # use automatic resource management.
        trainable = partial(tune_parameters, train_loader=train_loader, valid_loader=test_loader, config=config)

    tuner = tune.Tuner(
        trainable=trainable,
        tune_config=tune.TuneConfig( 
            num_samples=16, 
            metric="loss", 
            mode="min",
            ),
        run_config=train.RunConfig(name="mlflow"),
        param_space=conf
    )
   
    result = tuner.fit()

    print(f"Best config: {result.get_best_result(metric='loss', mode='min')}")