
from torch.utils.data import DataLoader

from wbvirtual.utils.arguments import parse_args
from wbvirtual.utils.config import Config
from wbvirtual.dataset import FileWBDataset
from wbvirtual.train.training import Training



def main_findlr():
    args = parse_args()

    # INPUT Parameters
    config = Config.create_from_args(args)

    train_dataset = FileWBDataset(
        args.dataset,
        train_flag=True,
        train_test_ratio=config.ratio_train_test,
        indices=args.indices,
        sensor_desc=config.sensors,
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers,
    )

    
    training = Training(config)
    training.find_lr(train_loader=train_loader)



def main_train():
    args = parse_args()

    # INPUT Parameters
    config = Config.create_from_args(args)

    train_dataset = FileWBDataset(
        args.dataset,
        train_flag=True,
        train_test_ratio=config.ratio_train_test,
        indices=args.indices,
        sensor_desc=config.sensors,
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers,
    )

    test_dataset = FileWBDataset(
        args.dataset,
        train_flag=False,
        train_test_ratio=config.ratio_train_test,
        indices=args.indices,
        sensor_desc=config.sensors,
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers,
    )

    training = Training(config)
    training.fit(train_loader=train_loader, valid_loader=test_loader)

