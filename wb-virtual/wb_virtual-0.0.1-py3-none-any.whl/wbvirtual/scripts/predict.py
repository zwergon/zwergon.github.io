
import argparse

import matplotlib.pyplot as plt

from torch.utils.data import DataLoader

from wbvirtual.utils.config import Config
from wbvirtual.utils.display import predictions_plot, distrib_plot
from wbvirtual.dataset import FileWBDataset
from wbvirtual.train.training import Training
from wbvirtual.train.feature import Feature

from wbvirtual.post.eq_load import eq_load
from wbvirtual.train.metric_distrib import MetricsDistrib
from sklearn.metrics import r2_score

def main_predict():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", help="path to parquet file")
    parser.add_argument("run_id", help="path to checkpoint")
    parser.add_argument("index", help="which element in the dataset", type=int)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "-s", "--span", help="range in timeserie to keep [S1, S2]", type=int, nargs=2
    )
    group.add_argument(
        "-a", "--all", help="display all timeserie (fullrange)", action="store_true"
    )
    parser.add_argument(
        "-i",
        "--indices",
        help="output indices [0..6] (Default:0)",
        nargs="+",
        type=int,
        default=[0],
    )
    parser.add_argument(
        "-n",
        "--norm",
        help="display prediction normalized or not",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "-c",
        "--config",
        help="training config file",
        type=str,
        default=Config.default_path(),
    )
    args = parser.parse_args()

    # INPUT Parameters
    config = Config.create_from_args(args)
    config.cuda = False

  
    test_dataset = FileWBDataset(
        args.dataset,
        train_flag=False,
        train_test_ratio=config.ratio_train_test,
        indices=args.indices,
    )
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=True)
    _, y_test = next(iter(test_loader))
    print(f"Number of predictions : {len(test_dataset)}")
    print(f"Shape of predictions : {y_test.shape}")
    print(f"Type Network: {config.type}")

    training = Training(config)
    training.predict(test_loader, run_id=args.run_id)
    
    if args.all:
        deb = 0
        end = training.predictions.actual.shape[2]
    else:
        deb = args.span[0]
        end = args.span[1]
    
    predictions_plot(training.predictions, index=args.index, span=[deb, end])
    
    feature = Feature(eq_load)
    feature.compute(training.predictions, m=3)

    print(f"r2score for DEL: {r2_score(feature.actual, feature.predicted)}")
    plt.figure()
    plt.scatter(feature.actual, feature.predicted)
    plt.show()

    r2 = MetricsDistrib(r2_score)
    r2.compute(training.predictions)
    distrib_plot(r2.distrib)
    plt.show()


